
var hoodies = [['UCLan Hoodie (1)','Purple','cotton authentic character and practicality are combined in this comfy' +
'  warm and luxury hoodie for students that goes with everything to create casual looks',' £39.99','/resources/images/hoodies/hoodie (1).jpg'],
    ['UCLan Hoodie (2)','Light Blue','cotton authentic character and practicality are combined in this comfy  warm' +
    ' and luxury hoodie for students that goes with everything to create casual looks',' £39.99','/resources/images/hoodies/hoodie (2).jpg'],
    ['UCLan Hoodie (3)','Green','cotton authentic character and practicality are combined in this comfy  warm and' +
    ' luxury hoodie for students that goes with everything to create casual looks',' £39.99','/resources/images/hoodies/hoodie (3).jpg'],
    ['UCLan Hoodie (4)','Dark Grey','cotton authentic character and practicality are combined in this comfy  warm' +
    ' and luxury hoodie for students that goes with everything to create casual looks',' £39.99','/resources/images/hoodies/hoodie (4).jpg'],
    ['UCLan Hoodie (5)','Black','cotton authentic character and practicality are combined in this comfy  warm and' +
    ' luxury hoodie for students that goes with everything to create casual looks',' £39.99','/resources/images/hoodies/hoodie (5).jpg'],
    ['UCLan Hoodie (6)','Salmon','cotton authentic character and practicality are combined in this comfy  warm and' +
    ' luxury hoodie for students that goes with everything to create casual looks',' £39.99','/resources/images/hoodies/hoodie (6).jpg'],
    ['UCLan Hoodie (7)','Burgundy','cotton authentic character and practicality are combined in this comfy  warm and' +
    ' luxury hoodie for students that goes with everything to create casual looks',' £39.99','/resources/images/hoodies/hoodie (7).jpg'],
    ['UCLan Hoodie (8)','Light Grey','cotton authentic character and practicality are combined in this comfy  warm' +
    ' and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (8).jpg'],
    ['UCLan Hoodie (9)','Slate Blue','cotton authentic character and practicality are combined in this comfy  warm' +
    ' and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (9).jpg'],
    ['UCLan Hoodie (10)','Orange','cotton authentic character and practicality are combined in this comfy  warm and' +
    ' luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (10).jpg'],
    ['UCLan Hoodie (11)','Teal','cotton authentic character and practicality are combined in this comfy  warm and' +
    ' luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (11).jpg'],
    ['UCLan Hoodie (12)','Navy','cotton authentic character and practicality are combined in this comfy  warm and' +
    ' luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (12).jpg'],
    ['UCLan Hoodie (13)','Orange','cotton authentic character and practicality are combined in this comfy  warm and' +
    ' luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (13).jpg'],
    ['UCLan Hoodie (14)','Creame','cotton authentic character and practicality are combined in this comfy  warm and' +
    ' luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (14).jpg'],
    ['UCLan Hoodie (15)','Lime','cotton authentic character and practicality are combined in this comfy  warm and' +
    ' luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (15).jpg'],
    ['UCLan Hoodie (16)','Off Blue','cotton authentic character and practicality are combined in this comfy  warm' +
    ' and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (16).jpg'],
    ['UCLan Hoodie (17)','Red','cotton authentic character and practicality are combined in this comfy  warm and' +
    ' luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (17).jpg'],
    ['UCLan Hoodie (18)','Charcoal','cotton authentic character and practicality are combined in this comfy  warm' +
    ' and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (18).jpg'],
    ['UCLan Hoodie (19)','Navy Blue','cotton authentic character and practicality are combined in this comfy  warm' +
    ' and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (19).jpg'],
    ['UCLan Hoodie (20)','Lighter Grey','cotton authentic character and practicality are combined in this comfy' +
    '  warm and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (20).jpg'],
    ['UCLan Hoodie (21)','New Blue','cotton authentic character and practicality are combined in this comfy  warm' +
    ' and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (21).jpg'],
    ['UCLan Hoodie (22)','Forest Green','cotton authentic character and practicality are combined in this comfy' +
    '  warm and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (22).jpg'],
    ['UCLan Hoodie (23)','Ocean Blue','cotton authentic character and practicality are combined in this comfy  warm' +
    ' and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (23).jpg'],
    ['UCLan Hoodie (24)','Pink','cotton authentic character and practicality are combined in this comfy  warm and' +
    ' luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (24).jpg'],
    ['UCLan Hoodie (25)','Orange New','cotton authentic character and practicality are combined in this comfy  warm' +
    ' and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (25).jpg'],
    ['UCLan Hoodie (26)','Black','cotton authentic character and practicality are combined in this comfy  warm and' +
    ' luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (26).jpg'],
    ['UCLan Hoodie (27)','Light Off Grey','cotton authentic character and practicality are combined in this comfy' +
    '  warm and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (27).jpg'],
    ['UCLan Hoodie (28)','Rusty Red','cotton authentic character and practicality are combined in this comfy  warm' +
    ' and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (28).jpg'],
    ['UCLan Hoodie (29)','Slate Grey','cotton authentic character and practicality are combined in this comfy  warm' +
    ' and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (29).jpg'],
    ['UCLan Hoodie (30)','Bright Green','cotton authentic character and practicality are combined in this comfy' +
    '  warm and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (30).jpg'],
    ['UCLan Hoodie (31)','Bright Pink','cotton authentic character and practicality are combined in this comfy  warm' +
    ' and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (31).jpg'],
    ['UCLan Hoodie (32)','Burgundy New','cotton authentic character and practicality are combined in this comfy' +
    '  warm and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (32).jpg'],
    ['UCLan Hoodie (33)','Navy New','cotton authentic character and practicality are combined in this comfy  warm' +
    ' and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (33).jpg'],
    ['UCLan Hoodie (34)','Bright Green','cotton authentic character and practicality are combined in this comfy' +
    '  warm and luxury hoodie for students that goes with everything to create casual looks',' £39.99','resources/images/hoodies/hoodie (34).jpg']];

var jumpers =[['UCLan Logo Jumper','Purple','cotton authentic character and practicality are combined in this winter' +
' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
' (1).jpg'],
    ['UCLan Logo Jumper','Rusty Red','cotton authentic character and practicality are combined in this winter jumper' +
    ' for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (2).jpg'],
    ['UCLan Logo Jumper','Water Blue','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (3).jpg'],
    ['UCLan Logo Jumper','White','cotton authentic character and practicality are combined in this winter jumper for' +
    ' students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper (4).jpg'],
    ['UCLan Logo Jumper','Pink','cotton authentic character and practicality are combined in this winter jumper for' +
    ' students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper (5).jpg'],
    ['UCLan Logo Jumper','Black','cotton authentic character and practicality are combined in this winter jumper for' +
    ' students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper (6).jpg'],
    ['UCLan Logo Jumper','Old Blue','cotton authentic character and practicality are combined in this winter jumper' +
    ' for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (7).jpg'],
    ['UCLan Logo Jumper','Dark Grey ','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (8).jpg'],
    ['UCLan Logo Jumper','Red','cotton authentic character and practicality are combined in this winter jumper for' +
    ' students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper (9).jpg'],
    ['UCLan Logo Jumper','Brown','cotton authentic character and practicality are combined in this winter jumper for' +
    ' students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper (10).jpg'],
    ['UCLan Logo Jumper','Green','cotton authentic character and practicality are combined in this winter jumper for' +
    ' students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper (11).jpg'],
    ['UCLan Logo Jumper','Dark Red','cotton authentic character and practicality are combined in this winter jumper' +
    ' for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (12).jpg'],
    ['UCLan Logo Jumper','Yellow','cotton authentic character and practicality are combined in this winter jumper' +
    ' for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (13).jpg'],
    ['UCLan Logo Jumper','Light Grey','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (14).jpg'],
    ['UCLan Logo Jumper','Light Green','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (15).jpg'],
    ['UCLan Logo Jumper','Old Red','cotton authentic character and practicality are combined in this winter jumper' +
    ' for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (16).jpg'],
    ['UCLan Logo Jumper','Light Purple','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (17).jpg'],
    ['UCLan Logo Jumper','Slate Blue','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (18).jpg'],
    ['UCLan Logo Jumper','Real Red','cotton authentic character and practicality are combined in this winter jumper' +
    ' for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (19).jpg'],
    ['UCLan Logo Jumper','Old Pink','cotton authentic character and practicality are combined in this winter jumper' +
    ' for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (20).jpg'],
    ['UCLan Logo Jumper','Slate Grey','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (21).jpg'],
    ['UCLan Logo Jumper','Bright Green','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (22).jpg'],
    ['UCLan Logo Jumper','Teal','cotton authentic character and practicality are combined in this winter jumper for' +
    ' students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper (23).jpg'],
    ['UCLan Logo Jumper','Sky Blue','cotton authentic character and practicality are combined in this winter jumper' +
    ' for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (24).jpg'],
    ['UCLan Logo Jumper','Sunshine Pink','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (25).jpg'],
    ['UCLan Logo Jumper','Bronze','cotton authentic character and practicality are combined in this winter jumper' +
    ' for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (26).jpg'],
    ['UCLan Logo Jumper','Olive Green','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (27).jpg'],
    ['UCLan Logo Jumper','Bright White Green','cotton authentic character and practicality are combined in this' +
    ' winter jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper (28).jpg'],
    ['UCLan Logo Jumper','Navy Blue','cotton authentic character and practicality are combined in this winter jumper' +
    ' for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (29).jpg'],
    ['UCLan Logo Jumper','Rusty Orange','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (30).jpg'],
    ['UCLan Logo Jumper','Bright Orange','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (31).jpg'],
    ['UCLan Logo Jumper','Sky Purple','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (32).jpg'],
    ['UCLan Logo Jumper','Really Red','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (33).jpg'],
    ['UCLan Logo Jumper','Plum Purple','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (34).jpg'],
    ['UCLan Logo Jumper','Dark Purple','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (35).jpg'],
    ['UCLan Logo Jumper','Vibrant Red','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (36).jpg'],
    ['UCLan Logo Jumper','Ocean Blue','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (37).jpg'],
    ['UCLan Logo Jumper','Creame','cotton authentic character and practicality are combined in this winter jumper' +
    ' for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (38).jpg'],
    ['UCLan Logo Jumper','Lighter Blue','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (39).jpg'],
    ['UCLan Logo Jumper','Light Grey','cotton authentic character and practicality are combined in this winter' +
    ' jumper for students that goes with everything to create casual looks',' £29.99','resources/images/jumpers/jumper' +
    ' (40).jpg']];

var tshirts = [['UCLan Logo Tshirt','Navy Blue New','cotton authentic character and practicality are combined in' +
' this summery t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (1).jpg'],
    ['UCLan Logo Tshirt','Rusty Red New','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (2).jpg'],
    ['UCLan Logo Tshirt','Burgundy','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (3).jpg'],
    ['UCLan Logo Tshirt','Pink','cotton authentic character and practicality are combined in this summery t-shirt' +
    ' for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (4).jpg'],
    ['UCLan Logo Tshirt','Teal','cotton authentic character and practicality are combined in this summery t-shirt' +
    ' for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (5).jpg'],
    ['UCLan Logo Tshirt','Black','cotton authentic character and practicality are combined in this summery t-shirt' +
    ' for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (6).jpg'],
    ['UCLan Logo Tshirt','Old Red','cotton authentic character and practicality are combined in this summery t-shirt' +
    ' for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (7).jpg'],
    ['UCLan Logo Tshirt','Grey','cotton authentic character and practicality are combined in this summery t-shirt' +
    ' for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (8).jpg'],
    ['UCLan Logo Tshirt','Red','cotton authentic character and practicality are combined in this summery t-shirt for' +
    ' students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (9).jpg'],
    ['UCLan Logo Tshirt','Brown','cotton authentic character and practicality are combined in this summery t-shirt' +
    ' for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (10).jpg'],
    ['UCLan Logo Tshirt','Pdark Purple','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (11).jpg'],
    ['UCLan Logo Tshirt','Yellow','cotton authentic character and practicality are combined in this summery t-shirt' +
    ' for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (12).jpg'],
    ['UCLan Logo Tshirt','Mustard Yellow','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (13).jpg'],
    ['UCLan Logo Tshirt','Dark Grey','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (14).jpg'],
    ['UCLan Logo Tshirt','Dark Green','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (15).jpg'],
    ['UCLan Logo Tshirt','Bright Green','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (16).jpg'],
    ['UCLan Logo Tshirt','Olive Green','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (17).jpg'],
    ['UCLan Logo Tshirt','Dark Grey','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (18).jpg'],
    ['UCLan Logo Tshirt','Orange','cotton authentic character and practicality are combined in this summery t-shirt' +
    ' for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (19).jpg'],
    ['UCLan Logo Tshirt','Purple','cotton authentic character and practicality are combined in this summery t-shirt' +
    ' for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (20).jpg'],
    ['UCLan Logo Tshirt','Slate Blue','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (21).jpg'],
    ['UCLan Logo Tshirt','Bright Pink','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (22).jpg'],
    ['UCLan Logo Tshirt','Brightly Green','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (23).jpg'],
    ['UCLan Logo Tshirt','Lime Green','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (24).jpg'],
    ['UCLan Logo Tshirt','Ocean Blue','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (25).jpg'],
    ['UCLan Logo Tshirt','Dark Red','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (26).jpg'],
    ['UCLan Logo Tshirt','Another Green','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (27).jpg'],
    ['UCLan Logo Tshirt','Slate Grey','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (28).jpg'],
    ['UCLan Logo Tshirt','Bright Orange','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (29).jpg'],
    ['UCLan Logo Tshirt','Another Purple','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (30).jpg'],
    ['UCLan Logo Tshirt','Real Red','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (31).jpg'],
    ['UCLan Logo Tshirt','Brilliant Blue','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (32).jpg'],
    ['UCLan Logo Tshirt','Creame','cotton authentic character and practicality are combined in this summery t-shirt' +
    ' for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (33).jpg'],
    ['UCLan Logo Tshirt','Teal Blue','cotton authentic character and practicality are combined in this summery' +
    ' t-shirt for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (34).jpg'],
    ['UCLan Logo Tshirt','White','cotton authentic character and practicality are combined in this summery t-shirt' +
    ' for students that goes with everything to create casual looks. Perfect for those summer days',' £19.99','resources/images/tshirt/tshirt (35).jpg']];


const allProducts = [...hoodies, ...jumpers, ...tshirts];

document.addEventListener("DOMContentLoaded", () => {
    const productsContainer = document.getElementById("products-container");
    if (productsContainer) {
        allProducts.forEach((product, index) => {
            const productCard = document.createElement("div");
            productCard.classList.add("product-card");
            productCard.innerHTML = `
                <img src="${product[4]}" alt="${product[0]}">
                <h3>${product[0]}</h3>
                <p>${product[1]}</p>
                <p>${product[2]}</p>
                <p><strong>${product[3]}</strong></p>
                <div class="product-buttons">
                    <button class="view-details-button" onclick="viewDetails(${index})">View Details</button>
                    <button class="cta-button" onclick="addToCart(${index})">Add to Cart</button>
                    <button class="view-cart-button" onclick="viewCart(${index})">View Cart</button>
                </div>
            `;
            productsContainer.appendChild(productCard);
        });
    }

    const productDetails = document.getElementById("product-details");
    if (productDetails) {
        const selectedIndex = sessionStorage.getItem("selectedProduct");
        if (selectedIndex) {
            const product = allProducts[selectedIndex];
            productDetails.innerHTML = `
                <img src="${product[4]}" alt="${product[0]}">
                <h3>${product[0]}</h3>
                <p>${product[1]}</p>
                <p>${product[2]}</p>
                <p><strong>${product[3]}</strong></p>
                <button class="cta-button" onclick="addToCart(${selectedIndex})">Add to Cart</button>
                <button class="view-cart-button" onclick="viewCart(${selectedIndex})">View Cart</button>
                <button class="shop-more-button" onclick="shopMore(${selectedIndex})">Continue Shopping</button>
            `;
        }
    }

    const cartContainer = document.getElementById("cart-container");
    if (cartContainer) {
        makeCart();
    }
});

function viewDetails(index) {
    sessionStorage.setItem("selectedProduct", index);
    window.location.href = "item.html";
}

function addToCart(index) {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push(allProducts[index]);
    localStorage.setItem("cart", JSON.stringify(cart));
    alert("Item added to cart!");
}
function viewCart(index){
    window.location.href = "cart.html";
}
function shopMore(index){
    window.location.href= 'products.html';
}

// this will render cart
function makeCart() {
    const cartContainer = document.getElementById("cart-container");
    const cart = JSON.parse(localStorage.getItem("cart")) || [];

    cartContainer.innerHTML = "";

    if (cart.length === 0) {
        cartContainer.innerHTML = "<p>Your cart is empty, check out our products <a href='products.html'>here</a></p> ";
        return;
    }

    cart.forEach((product, index) => {
        const cartItem = document.createElement("div");
        cartItem.classList.add("cart-item");
        cartItem.innerHTML = `
            <img src="${product[4]}" alt="${product[0]}">
            <h3>${product[0]}</h3>
            <p>${product[1]}</p>
            <p>${product[2]}</p>
            <p><strong>${product[3]}</strong></p>
            <button class="remove-button" onclick="removeFromCart(${index})">Remove</button>
        `;
        cartContainer.appendChild(cartItem);
    });

    const totalPrice = cart.reduce((total, product) => {
        const price = parseFloat(product[3].replace("£", ""));
        return total + price;
    }, 0);

    const totalContainer = document.createElement("div");
    totalContainer.classList.add("total-container");
    totalContainer.innerHTML = `<h3>Total: £${totalPrice.toFixed(2)}</h3>`;
    cartContainer.appendChild(totalContainer);
}

// Remove item from cart
function removeFromCart(index) {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    makeCart();
}

